<?php

namespace controllers;

class IndexController extends \zblog\controller\ControllerAbstract
{
	public $view;
	
	public function indexAction()
	{
		$this->view->setVar('urlHome', URL_HOME);
		$this->view->setVar('applicationName', APP_NAME);
		$this->view->setVar('pageTitle', "Main Page");

		$modelBlogs = new \models\Blogs();

		//Get all Entries
		$entries = $modelBlogs->getEntries();
		
		$this->view->setVar('entries', $entries);

		//Get Recent entries for the sidebar
		$recentEntries = $modelBlogs->getRecentEntries();
		
		$this->view->setVar('recententries', $recentEntries);
		
	}

	public function togglepreviewAction()
	{
		/* -- CODEBREAK m6ex4: Cookies -- */
	}
}