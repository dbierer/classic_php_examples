<?php

namespace controllers;

use models;
use \zblog\util\Validators;

class AdminController extends \zblog\controller\ControllerAbstract  
{

	const SHOW_COMMENT = 1;
	const HIDE_COMMENT = 2;
	
	public function __construct()
	{
		$this->preDispatchCall = new \zblog\controller\AuthenticationManager();
	}
	
	public function indexAction() 
	{

		$this->view->setVar('applicationName', APP_NAME);
		$this->view->setVar('urlHome', URL_HOME);
		$this->view->setVar('pageTitle', "Admin Page");
		$this->view->setVar('pageAction', 'adminmain');
		
		//Default is list all entries
		$entries = \models\Blogs::getEntryTitles();
		$this->view->setVar('entries', $entries);
    }

        
    public function newentryAction()
    {

    	$this->view->setVar('applicationName', APP_NAME);
		$this->view->setVar('urlHome', URL_HOME);
    	$this->view->setVar('pageAction', 'newentry');
    	$request = $this->view->getRequestParams();
    	$this->view->setVar('newEntry', true);
    	$this->view->setVar('pageTitle', "Create a new Blog entry");

    	if (array_key_exists('submit', $request)) {
    		if ($request['submit'] == 'Create') {

    			if ($request['title'] && $request['blog-content'] ) {

    				$entry = array();
    				$entry['title'] = $request['title'];
    				$entry['content'] = $request['blog-content'];
    				$entryId = models\Blogs::createEntry($entry);

    				if ($entryId) {
    					$entry['entryId'] = $entryId;

    					$this->view->setVar('message', 'The blog entry was successfully added!');
    				}

    			} else {
    				$this->view->setVar('message', 'Expected: Title (1 to 120 chars), Entry (1 to 2000 chars)');
    			}
    		}
    	}

    }

    public function managecommentsAction()
    {

    	$this->view->setVar('applicationName', APP_NAME);
		$this->view->setVar('urlHome', URL_HOME);
    	$this->view->setVar('pageAction', 'managecomments');
    	$this->view->setVar('pageTitle', "Manage Comments");

    	//Default is list all
    	//Can show or hide comments

    	$request = $this->view->getRequestParams();

    	//Set appropriate status
    	if (array_key_exists('id', $request)) {
    		$commentId = $request['id'];
    		if (($commentId != '') || ($commentId != 0)) {
    			if (array_key_exists('display', $request)) {
    				if ($request['display'] == 'hide') {

    					//Set Hidden in database
    					\models\Blogs::updateCommentStatus($commentId, self::HIDE_COMMENT );


    				} elseif ($request['display'] == 'show') {

    					//Set Visible in database

    					\models\Comments::updateCommentStatus($commentId, self::SHOW_COMMENT );
    				}
    			}
    		}
    	}
    	$blogComments = \models\Comments::getAllComments();
    	$this->view->setVar('comments', $blogComments);
    }
    
    public function logsAction() 
    {
    	$this->view->setVar('applicationName', APP_NAME);
 		$this->view->setVar('urlHome', URL_HOME);
     	$this->view->setVar('pageAction', 'logs');
     	$this->view->setVar('pageTitle', "Logs");
 
     	/**
     	 * L3Ex3: download log file - complete
     	 */
     	$logs = array();
     	$this->view->setVar('logs', $logs);
     }
     
     public function logdownloadAction()
     {
     	$request = $this->view->getRequestParams();
     	$logFile = $request['file'];

     	/**
     	 * L3Ex3: download log file - complete
     	 */
     }

     public function changepasswordAction() 
     {
     	$this->view->setVar('applicationName', APP_NAME);
 		$this->view->setVar('urlHome', URL_HOME);
     	$this->view->setVar('pageAction', 'changepassword');
     	$this->view->setVar('pageTitle', "Change password");
 
     	$request = $this->view->getRequestParams();
     	
     	if(array_key_exists('submit', $request))
     	{
 			$errMsg = '';
     		
 			$username = $_SESSION['user'];
 			$loggedUser = \models\Users::getUser($username);
 
 			$currentPassword = $request['current'];
 			$newPassword = $request['new'];
 			$confirmPassword = $request['confirm'];
 
 			if($currentPassword != $loggedUser->password) 
 			{
 				$errMsg .= '<p>The current password does not match</p>';
 			}
 			
 			/**
 			 * Lesson 5: Add the validPassword validator - complete
 			 */
 			
 			
 			
 			if(0 !== strcmp($newPassword, $confirmPassword))
 			{
 				$errMsg .= '<p>The password and confirm password do not match</p>';
 			}
 			
 			if($errMsg == '') {
 				//Everything is valid, do the change.
 				$success = \models\Users::changePassword($loggedUser->username, $newPassword);
 				
 				if($success) {
 					$this->view->setVar('message', 'Password was successfully changed.');
 				} else {
 					$this->view->setVar('message', 'Could not change password. An error has occured.');
 				}
 			} else {
 				$this->view->setVar('message', $errMsg);
 			}
     	}
     }     
}