<?php

namespace models;

/**
 * models/Soap.php 
 * File contains the \models\Soap class.
 * Class providing data for Soap related operations.
 * 
 * @author Zend Technologies Inc.
 */


class Soap
{

    /**
     * function gets all Blog entries in the db
     *
     * @return mixed - result set containing all records in the listings table
     * 
     * getArticles: returns an array of rows, each of which is an associative array. 
     * The keys of the associative array are the columns or column aliases named in the select query.
     */
    public function getArticles() 
    {
    	$return = array();
    	/** 
    	 * TODO: Populate the $return variable to become a two dimentional array  
    	 * where the outer array has an element per blog entry and contains an 
    	 * associative array with blog data (hint: use Blogs::getEntries() to get
    	 * the data and use utf8_encode() to prevent SOAP encoding problems)
    	 */

    	return $return;
    }

}
