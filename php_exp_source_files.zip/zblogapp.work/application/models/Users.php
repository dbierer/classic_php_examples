<?php

namespace models;

use \zblog\data\Adapter as DatabaseAdapter;
use \zblog\log\Logger;

/**
 * models/Users.php 
 * File contains the ZBlog_Model_Users class.
 * Class for Database manip operations.
 * 
 * @author Zend Technologies Inc.
 */

/**
 * ZBlog_Model_Users
 * Class contains methods for manipulating the BLOGS data stored
 * in SQLite database.
 *
 */
class Users
{
	
	
	public static function loginUser($userName, $password)
	{
		
		$results = array();
		try {
		
			$sql = <<<EOQ
SELECT user_id, real_name 
FROM blogusers 
WHERE username = ?
AND password = ?
EOQ;
			
			$stmt = DatabaseAdapter::getAdapter()->prepare( $sql );
			if ($stmt->execute(array($userName, $password))) {
    			return $stmt->fetch(\PDO::FETCH_OBJ);
			}
		} catch (PDOException $e) {
			Logger::getInstance()->writeLog($e->getMessage(), 'ERR');
		}
		
		return null;
	}
	
	/**
	 * L5Ex2:
	 * Chage password
	 * @param string $username
	 */
 	public static function getUser($username)
 	{
 	}
 	
 	public static function changePassword($username, $password)
 	{
 	}
}