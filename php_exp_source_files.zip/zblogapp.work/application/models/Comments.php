<?php

namespace models;

use \zblog\data\Adapter as DatabaseAdapter;
use \zblog\log\Logger;
/**
 * models/Comments.php 
 * File contains the ZBlog_Model_Comments class.
 * Class for Database manip operations.
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog_Model_Comments
 * Class contains methods for manipulating the BLOGS data stored
 * in SQLite database.
 *
 */
class Comments
{
	
	/**
	 * Adds Comments
	 *
	 * @param string $comment
	 * @return int The new comment ID
	 */
	
    public static function AddComment($comment) 
    {
		/*
		 * Exercise 8b: implement the AddComment function
		 */

		return null;
    } 

    /**
     * Retrieves a single Comments
     *
     * @param int $entryId
     * @return array
     */
    
    public static function getComments($entryId) 
    {
    	
    	$sql = <<<EOQ
SELECT * 
FROM blogcomments
WHERE
entry_id = ?
AND approval_status = 1    	
ORDER BY modified DESC
EOQ;
    	try {
    		$stmt = DatabaseAdapter::getAdapter()->prepare( $sql );
    		if ($stmt->execute(array($entryId))) {
    			return $stmt->fetchAll(\PDO::FETCH_OBJ);
    		}
    	} catch (\PDOException $e) {

    		Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );

    	}
    	return null;
    }
    
    /**
     * Get all Comments
     *
     * @return array
     */

    public static function getAllComments() 
    {
		/*
		 * M8Ex3: implement the getAllComments function
		 */
    	
    	return null;
    	
    }

    /**
     * Updates the status of a given comment
     *
     * @param string $commentId The comment to update
     * @param string $status The status
     */
    
    public static function updateCommentStatus($commentId, $status) 
    {
		
    	$commentId = (int) $commentId;
    	$status = (int) $status;
       
    	$sql = <<<EOQ
UPDATE blogcomments SET approval_status = ? WHERE comments_id = ?
EOQ;
    	
		try {
			
    		$stmt = DatabaseAdapter::getAdapter()->prepare( $sql );
    		$stmt->execute(array($status, $commentId));
		} catch (\PDOException $e) {
			
			Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );
			
		}
    }
}