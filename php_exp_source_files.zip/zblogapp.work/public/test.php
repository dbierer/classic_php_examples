<pre>
<?php
$requestPath = dirname($_SERVER['SCRIPT_NAME']);
$requestUri = $_SERVER['REQUEST_URI'];

if (($pos = strpos($requestUri, '?')) !== false) {
	$requestUri = substr($requestUri, 0, $pos - 1);
}

$start = $requestPath == '/' ? 1 : strlen($requestPath);
$request = substr($requestUri, $start);
if ($request === false) {
	$params = array();
} else {
	$params = explode( "/", $request );
}

var_dump($params);

$sql = <<<EOQ
SELECT entry_id, title, modified 
FROM blogentries 
ORDER BY modified DESC
LIMIT 0,5
EOQ;

$db  = 'sqlite:../data/blogdb.sqlite'; 
$pdo = new PDO($db);

$stmt = $pdo->prepare($sql);
if ($stmt->execute()) {
	while (($row = $stmt->fetch()) !== false) {
		var_dump($row);
	}
}