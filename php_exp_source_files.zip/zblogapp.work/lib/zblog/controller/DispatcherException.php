<?php

namespace zblog\controller;

/**
 * ZBlog/Controller/Exception.php
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog Dispatcher Exception Class
 *
 */
class DispatcherException extends \zblog\Exception 
{
}