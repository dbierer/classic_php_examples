<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

require_once '../config/config.inc.php';

/**
 * ZBlog front controller
 */

$path = realpath(dirname(__FILE__).DIRECTORY_SEPARATOR.'..').DIRECTORY_SEPARATOR;

set_include_path(
	$path.'lib'.PATH_SEPARATOR
	. $path.'application'.PATH_SEPARATOR
	. $path.'config'.PATH_SEPARATOR
	. get_include_path()
);

require_once 'zblog/loader/LoggingAutoloader.php';

\zblog\loader\LoggingAutoloader::getInstance();

$dispatcher = new zblog\controller\Dispatcher();
$dispatcher->dispatch();

