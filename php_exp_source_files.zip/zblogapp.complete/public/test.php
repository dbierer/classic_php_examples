<pre>
<?php
ini_set('display_errors', 1);

$sql = <<<EOQ
SELECT entry_id, title, modified 
FROM blogentries 
ORDER BY modified DESC
LIMIT 0,5
EOQ;

define( 'APP_PATH', realpath(dirname(__FILE__).DIRECTORY_SEPARATOR.'..').DIRECTORY_SEPARATOR );
define( 'DB_PATH', APP_PATH . 'data' . DIRECTORY_SEPARATOR );
const DB_NAME = 'blogdb.sqlite';
$db  = DB_PATH . DB_NAME;
$pdo = new PDO('sqlite:' . $db);

$stmt = $pdo->prepare($sql);
if ($stmt->execute()) {
	while (($row = $stmt->fetch()) !== false) {
		var_dump($row);
	}
}
?>
</pre>