<?php

class View_Helper_SendPage 
{

	public $view;
		
	public function load() 
	{
		$urlHome = $this->view->getVar('urlHome');
		$pageTitle = $this->view->getVar('pageTitle');
		$applicationName = $this->view->getVar('applicationName');
		$entry = $this->view->getVar('entry');
		$error = $this->view->getVar('error');
		$name= $this->view->getVar('name');
		$email= $this->view->getVar('email');
		$friend= $this->view->getVar('friend');
		$comment= $this->view->getVar('comment');
		$delivery= $this->view->getVar('delivery');
		
		if (!empty($delivery)) {
			$sendDisplay='<div class="listings"><h2>'.$delivery.'</h2></div>';
			return $sendDisplay;
		}
		
		$sendDisplay='<div class="listings"><form name="send" action="'.$urlHome . '/article/send/id/' . $entry->entry_id.'" method="post">';
		$sendDisplay.= '<h3>'.htmlentities($entry->title, ENT_NOQUOTES).'</h3>';
		$sendDisplay.= '<h2>Send this article to a friend</h2>';

		if (!empty($error)) {
			$sendDisplay.='<div class="error"><p>'.$error.'</p></div>';
		}
		
		$sendDisplay.= <<<EOQ
	<table width="400">
		<tr>
			<td width="40%">Your Name</td>
			<td width="60%"><input type="text" name="name" size="20" value="$name"></td>
		</tr>
		<tr>
			<td width="40%">Your Email</td>
			<td width="60%"><input type="text" name="email" size="20" value="$email"></td>
		</tr>
		<tr>
			<td width="40%">Friend's Email</td>
			<td width="60%"><input type="text" name="friend" size="20" value="$friend"></td>
		</tr>
		<tr>
			<td width="40%">Comment</td>
			<td width="60%"><textarea cols="40" rows="5" name="comment">$comment</textarea></td>
		</tr>
		<tr>
			<td width="40%"></td>
			<td width="60%"><input type="submit" value="Send"></td>
		</tr>	
	</table>
</form>	
</div>		
EOQ;
		
		return  $sendDisplay;
        
    }
}