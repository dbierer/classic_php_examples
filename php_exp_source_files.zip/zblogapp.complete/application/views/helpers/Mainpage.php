<?php

class View_Helper_Mainpage 
{

	public $view;
	
	public function load() 
	{
		
		$urlHome = $this->view->getVar('urlHome');
		$entries = $this->view->getVar('entries');
		
		if ($entries) {
			
			$entryDisplay = '';

			foreach ($entries as $entry) {
				$entryDisplay .= '<div class="listings">';
				$entryDisplay .= '<h3><a href="' . $urlHome . '/article/view/id/' . $entry->entry_id . '">' . htmlentities($entry->title, ENT_NOQUOTES) . '</a></h3>';
				if (!isset($_COOKIE['hidePreview'])) {
					if (strlen($entry->content) > 500) {
						$entryDisplay .= '<p>' . $entry->content . '<a href="' . $urlHome . '/article/view/id/' . $entry->entry_id . '">Read More</a></p>';
					} else {
						$entryDisplay .= '<p>' . htmlentities($entry->content, ENT_NOQUOTES) . '</p>';
					}
				}
				$entryDisplay .= '<p>By author | <a href="' . $urlHome . '/article/view/id/' . $entry->entry_id . '">' . $entry->comments_count . ' comments</a> | ' . date('D, M j, Y  h:i a T', $entry->modified) . '</p>';
				$entryDisplay .= '</div>';
								
			}
			
		}
		
        return  $entryDisplay; 
        
    }
    
}