<?php
//require_once( 'MyBlog/Utils.php' );

class View_Helper_Adminpage 
{

	public $view;
		
    public function load()
    {
    	$urlHome 	= $this->view->getVar('urlHome');
   		$pageAction	= $this->view->getVar('pageAction');;
    	$pageTitle 	= $this->view->getVar('pageTitle');
    	$applicationName = $this->view->getVar('applicationName');
		$message 	= $this->view->getVar('message');
		
    	if ($pageAction == 'newentry') {
    		
    		$newSubmit		= '<input type="submit" name="submit" value="Create" size="10">';
    		$textAreaLabel	= '<label for="blog-content">Blog Entry</label>';
    		$textArea		= '<textarea name="blog-content" id="edit-article"></textarea>';
    		$titleLabel		= '<label for="title">Title for your entry</label>';
    		$titleInput		= '<input type="text" name="title" id="f_l_title" size="40" maxlength="120">';
        
    		$pageHtml = <<<EOQ
<div id="admin-form">			
	<h2>$pageTitle</h2>
	<div class="error">$message</div>			
	<div class="item">
	<form action="$urlHome/admin/newentry" method="post">
		$titleLabel
		<div class="input">
			$titleInput
    	</div>	
    	$textAreaLabel
    	<div class="input">	
			$textArea
    	</div>	
		<div class="input">	
			$newSubmit
    	</div>		
				
	</form>
</div>				
EOQ;
    		
    		return $pageHtml;
    		
		} elseif ($pageAction == 'managecomments') {
			
			$comments = $this->view->getVar('comments');

			$commentsList = '';
			
			if ($comments) {
				
				foreach ($comments as $comment) {
					
					$commentsList .= '<div class="listings">';
					
					if ($comment->approval_status == 1) {
						$commentLink = '<a href="' . $urlHome . '/admin/managecomments/id/' . $comment->comments_id . '/display/hide" title="Do not show this comment">Hide</a>';
						
					} elseif ($comment->approval_status == 2) {
						$commentLink = '<a href="' . $urlHome . '/admin/managecomments/id/' . $comment->comments_id . '/display/show" title="Show this comment">Show</a>';
						
					} else {
						$commentLink = '<span class="bold">NEW!</span> <a href="' . $urlHome . '/admin/managecomments/id/' . $comment->comments_id . '/display/show" title="Do not show this comment">Show</a> | <a href="' . $urlHome . '/admin/managecomments/id/' . $comment->comments_id . '/display/hide" title="Do not show this comment">Hide</a>';
					}
					
					$commentsList .= '<p><h3>' . htmlentities($comment->title, ENT_NOQUOTES) . '</h3></p>';		
					$commentsList .= '<p>' . htmlentities($comment->comment, ENT_NOQUOTES) . '</p>';		
					$commentsList .= '<p>' . $commentLink . '</p>';
					$commentsList .= '</div>';
						
				}
			}
						
			$pageHtml = <<<EOQ
				<h2>Manage Comments</h2>
				$commentsList
EOQ;

			return  $pageHtml;
		} elseif ($pageAction == 'changepassword') {
 			$passwordSubmit		= '<input type="submit" name="submit" value="Change password" size="10">';
 			$currentPasswordLabel = '<label for="current">Current password</label>';
 			$currentPasswordInput = '<input type="password" name="current" id="current" size="20" maxlength="50">';
 			$newPasswordLabel = '<label for="new">New password</label>';
 			$newPasswordInput = '<input type="password" name="new" id="new" size="20" maxlength="50">';
 			$confirmPasswordLabel = '<label for="confirm">Confirm password</label>';
 			$confirmPasswordInput = '<input type="password" name="confirm" id="confirm" size="20" maxlength="50">';
 			
 			$pageHtml = <<<EOQ
 <div id="admin-form">			
 	<h2>$pageTitle</h2>
 	<div class="error">$message</div>			
 	<div class="item">
 	<form action="$urlHome/admin/changepassword" method="post">
 		$currentPasswordLabel
 		<div class="input">
 			$currentPasswordInput
     	</div>
     	$newPasswordLabel
     	<div class="input">	
 			$newPasswordInput
     	</div>	
     	$confirmPasswordLabel
     	<div class="input">	
 			$confirmPasswordInput
     	</div>	
 		<div class="input">	
 			$passwordSubmit
     	</div>		
 	</form>
 </div>					
EOQ;
 			
 			return $pageHtml;
 		} elseif ($pageAction == 'logs') {
 			$pageHtml = '<div id="admin-form">
						 <h2>'.$pageTitle.'</h2>
			 			 <ul>';
 			
 			foreach($this->view->getVar('logs') as $log)
 			{
 				$logname = basename($log);
 				$pageHtml .=  "<li><a href=$urlHome/admin/logdownload/file/$logname>$logname</a></li>";
 			}
 			
 			$pageHtml .= '</ul></div>';
 			return $pageHtml;
 		} else {
			$entries = $this->view->getVar('entries');
			
			$entriesList = '';
			
			if ($entries) {

				$entriesList = '<ul>';
				
				foreach ($entries as $entry) {
					$entriesList .= '<li><a href="' . $urlHome . '/article/view/id/' . $entry->entry_id . '" title="Opens in a new window" target="_blank">' . htmlentities($entry->title, ENT_NOQUOTES) . '</a></li>';		
				}
				
				$entriesList .= '</ul>';
			}
			
			$pageHtml = <<<EOQ
				
				<h2>Manage Blog Entries</h2>
				
				
				$entriesList
		
EOQ;

			return  $pageHtml;
			
		}
    }
}