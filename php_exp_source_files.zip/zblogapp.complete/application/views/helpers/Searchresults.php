<?php

class View_Helper_Searchresults
{

	public $view;
		
	
	public function load() 
	{
		$urlHome = $this->view->getVar('urlHome');
		$entries = $this->view->getVar('entries');
		$query 	 = $this->view->getVar('query');
		
		if ($entries) {
			
			$entryDisplay = '';
			$entryDisplay = '<h3>Results for: ' . htmlentities($query, ENT_NOQUOTES) . '</h3>';		
			
			foreach ($entries as $entry) {
				
				$entryDisplay .= '<p><a href="' . $urlHome . '/article/view/id/' . $entry->entry_id . '">' . htmlentities($entry->title, ENT_NOQUOTES) . '</a></p>';
				
			}
		} else {
			$entryDisplay = '<h3>Your search for ' . htmlentities($query, ENT_NOQUOTES) . ' did not return results!</h3>';		
		}
		
        return  $entryDisplay; 
        
    }
}