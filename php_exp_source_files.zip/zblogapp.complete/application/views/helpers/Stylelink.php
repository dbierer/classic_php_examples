<?php

class View_Helper_Stylelink
{

	public $view;
		
	public function load() 
	{
		return '<link rel="stylesheet" type="text/css" href="' . URL_STYLES . '">';
    }
}