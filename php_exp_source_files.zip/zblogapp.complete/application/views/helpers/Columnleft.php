<?php

class View_Helper_Columnleft 
{

	public $view;
		
	public function load() 
	{
		
		$urlHome = $this->view->getVar('urlHome');
		$columnLeftHtml = '';
		
        $searchBoxHtml = <<<EOQ
<div id="blog-search-box">
<form action="$urlHome/search/" method="get">
    <p>
        <input type="text" name="q" size="25" maxlength="255">
        <input type="submit" name="submit" value="Search" size="10">
    </p>
</form>
</div>
EOQ;

        $recentEntries = $this->view->getVar('recententries');
		if ($recentEntries) {
			
			$recentEntriesDisplay = '';
			$recentEntriesDisplay .= '<ul>';
			foreach ($recentEntries as $recentEntry) {
				
				$recentEntriesDisplay .= '<li><a href="' . $urlHome . '/article/view/id/' . $recentEntry->entry_id . '">' . htmlentities($recentEntry->title, ENT_NOQUOTES) . '</a></li>';
			}
			$recentEntriesDisplay .= '</ul>';
			
		}        
           
        $recentEntriesHtml = <<<EOQ
<div id="blog-recentposts">        
	<h3>Recent Posts</h3>
	$recentEntriesDisplay
</div>
EOQ;

$rssBoxHtml = <<<EOQ
<div id="blog-search-box">
    <p>
		<a href="$urlHome/rss"><img src="/images/feed-icon.png" border="0"></a> <a href="$urlHome/rss">Subscribe to ZBlog RSS Feed</a>
    </p>
</div>
EOQ;
		
		/**
		 * M6Ex6: Part 2: Displaying the last read article. 
		 * 			
		 */
		$lastReadHtml = '';
        if (isset($_SESSION['lastread'])) {
             $lastReadHtml = <<<EOQ
<div id="blog-recentposts">
<h3>Last Article</h3>
<p>
<a href="$urlHome/article/view/id/{$_SESSION['lastread']->entry_id}">
     {$_SESSION['lastread']->title}
     </a>
     </p>
</div>
EOQ;
  	    }

        
        $columnLeftHtml = $searchBoxHtml . $recentEntriesHtml . $lastReadHtml . $rssBoxHtml;
                
        return $columnLeftHtml;
        
    }
}