<?php

namespace controllers;

class SearchController extends \zblog\controller\ControllerAbstract 
{
	public $view;
	
	public function indexAction()
	{

		$this->view->setVar('urlHome', URL_HOME);
		$this->view->setVar('applicationName', APP_NAME);
		$this->view->setVar('pageTitle', "Search");
		$query = '';
		
		//$request = $this->view->getRequestParams();
		
		$entries = '';
		$query = $_GET['q'];
		
		if ($query != '') {
			$entries = \models\Blogs::searchEntries($query);
		}
		$this->view->setVar('query', $query);
		$this->view->setVar('entries', $entries);

		//Get Recent entries for the sidebar
		$recentEntries = \models\Blogs::getRecentEntries();

		$this->view->setVar('recententries', $recentEntries);

	}
	public function testAction(){}

}