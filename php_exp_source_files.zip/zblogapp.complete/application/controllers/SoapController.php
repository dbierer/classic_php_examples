<?php

namespace controllers;

use models;

class SoapController extends \zblog\controller\ControllerAbstract 
{
	public function indexAction()
	{
		header('Location: http://'.$_SERVER['SERVER_NAME'].'/soap/wsdl/');
	}

	public function wsdlAction()
	{
		require_once 'Zend/Soap/AutoDiscover.php';
		
		$uri = 'http://'.$_SERVER['SERVER_NAME'].'/soap/server/';
		
		$autodiscover = new \Zend_Soap_AutoDiscover(true, $uri);
		$autodiscover->setClass('\models\Soap');
		
		header ("Content-Type:text/xml");
		echo $autodiscover->toXml();
		exit;
	}
	
	public function serverAction()
	{
		$server = new \SoapServer('http://'.$_SERVER['SERVER_NAME'].'/soap/wsdl/');
		$server->setClass('\models\Soap');
		
		header ("Content-Type:text/xml");
		$server->handle();
		exit;
	}
	
	public function clientAction()
	{
		$client = new \SoapClient('http://'.$_SERVER['SERVER_NAME'].'/soap/wsdl/');
		$res = $client->getArticles();
		
    	foreach ($res AS $entry) {
    		foreach ($entry AS $key => $val) {
    			echo $key.': '.utf8_decode($val).'<br>';
    		}
    	}
		exit;
	}
	
}