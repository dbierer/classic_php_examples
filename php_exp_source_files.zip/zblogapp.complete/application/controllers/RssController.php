<?php

namespace controllers;

use zblog\controller;

class RssController extends \zblog\controller\ControllerAbstract 
{
	public $view;
	
	public function indexAction()
	{
		//Get Recent entries for RSS feed
		$entries = \models\Blogs::getRecentEntries();
		$recentEntries = array();
		
		$tmp = array();
		
		$maxCount = 5;
		$count = 0;
		
		// Note, the example here is not an example of best practices, rather
		// it is an example of using a goto statement
		for ($i=0; $i<count($entries); $i++) {
			
			if (++$count > $maxCount) {
				goto end;
			}
			
			$tmp = array(
					'title' => $entries[$i]->title,
					'link' => URL_HOME . '/article/view/id/' . $entries[$i]->entry_id,
					'pubDate' => date('D, M j, Y  h:i a T', $entries[$i]->modified),
					);
							
		
			$recentEntries[$i] = $tmp;
		}
		
		end:
		echo \zblog\rss\FeedBuilder::generateRssFeed($recentEntries);
		$this->postDispatchCall = function() { exit; };
	}
}