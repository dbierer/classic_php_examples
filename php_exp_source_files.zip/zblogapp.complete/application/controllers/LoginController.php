<?php
namespace controllers;

use \zblog\util\Validators as Validators;

class LoginController extends \zblog\controller\ControllerAbstract
{

	public function httpAction()
	{
		
		if (isset($_SERVER['PHP_AUTH_USER'])) {
			$userName = $_SERVER['PHP_AUTH_USER'];
			$password = $_SERVER['PHP_AUTH_PW'];
			if (Validators::validUserName($userName) && Validators::validPassword($password)) {
				$validData = true;
			} 

			//Pass to the authentication system only if valid data has been entered
			if ($validData) {
				
				$result = \models\Users::loginUser($userName, $password);

				if ($result) {

					//Store logged in username to the session

					$_SESSION['user'] = $userName;
					$_SESSION['isLoggedIn'] = true;

					$_SESSION['userId'] = $result->user_id;
					$_SESSION['realName'] = $result->real_name;

					header('Location:' . URL_HOME . '/admin');
					return;
				}
			}		
		}
		
		header('Not Authorized', true, 401);
		header('WWW-Authenticate: Basic realm="ZBlog"');
		
	}
	
	public function indexAction()
	{
		
		$this->view->setVar('urlHome', URL_HOME);
		$this->view->setVar('pageTitle', "Login");
		$this->view->setVar('errorMessage', '');
		$request = $this->view->getRequestParams();
		if (array_key_exists('login_submit_check', $request)) {
			if ( $request['login_submit_check'] == 1 ) {
				$resultcode = 0;
				$userName = '';
				$validData = false;
				$validUserName = false;
				$validPasswd = false;

				
				$userName = $request['user_name'];
				$password = $request['passwd'];
				//validate username and password here
				
				if (Validators::validUserName($userName) && Validators::validPassword($password)) {
					$validData = true;
				} 

				//Pass to the authentication system only if valid data has been entered
				if ($validData) {
					
					$result = \models\Users::loginUser($userName, $password);

					if ($result) {

						//Store logged in username to the session

						$_SESSION['user'] = $userName;
						$_SESSION['isLoggedIn'] = true;

						$_SESSION['userId'] = $result->user_id;
						$_SESSION['realName'] = $result->real_name;

						header('Location:' . URL_HOME . '/admin');

					} else {
						$this->view->setVar('errorMessage', 'Invalid credentials!');
					}
				} else {
					
						$this->view->setVar('errorMessage', 'Invalid credentials!');
				}
	
			}
		}
	}
}