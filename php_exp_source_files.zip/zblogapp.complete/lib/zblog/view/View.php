<?php

namespace zblog\view;

use zblog\log;

/**
 * zblog/view/View.php
 * 
 * @author Zend Technologies Inc.
 */

/**
 * View Class
 * Provides methods to route request from the UI to the 
 * appropriate controller and assigns view to the request
 */

class View
{
	
	private $_script;
	private $_requestParams;
	private $_viewVars = array();
	private $_viewHelperPath;
	
	
	public function render()
	{
		if ( file_exists($this->_script) == false ) {
			throw new Exception('View: "' . $this->_script . '" not found');
		}
		
		include_once( $this->_script );
	}
	
	public function setVar( $varName, $value )
	{
		$this->_viewVars[$varName] = $value;
		return true;	
	}
	
	public function getVar( $varName )
	{
		if ( array_key_exists($varName, $this->_viewVars) ) {
			return $this->_viewVars[$varName];
		} else {
			return false;
		}
	}
	
	public function setScript( $script ) 
	{
		$this->_script = $script;
	}
	
	private function _setHelperPath() 
	{
		$helperPath = APP_PATH . 'application' . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR;
		
		if (!is_dir( $helperPath )) {
			
			$err_msg = 'Helper Path not found ...';
	    	echo '<h2>An Error Occured!</h2>';
	    	echo $err_msg;
	    	throw new Exception( $err_msg );
			
		}
		$this->_viewHelperPath = $helperPath;
	}
	
	public function loadHelper( $helperName )
	{
		$this->_setHelperPath();
		$helperFile = $this->_viewHelperPath . $helperName . '.php';		
		if ( file_exists( $helperFile ) == false ) {
			throw new Exception('View Helper: "' . $helperName . '" not found');
		}
		
		include_once( $helperFile );
		
		$className = 'View_Helper_' . $helperName;
	    if (class_exists($className, false)) {
           $helperObj = new $className();
           $helperObj->view = $this;
           return $helperObj->load();
	    }   
	}
	
	public function setRequestParams( $params )
	{
		
		$this->_requestParams = $params;
	}
	
	public function getRequestParams() {
		return $this->_requestParams;
	}
}