<?php

namespace zblog\rss;

use \zblog\log\Logger;

class FeedBuilder
{

	public static function generateRssFeed( $recentEntries )
	{
		try {
			//create xml doc
			$doc = new \DOMDocument("1.0");

			//create the rss element
			$root = $doc->createElement('rss');
			$root = $doc->appendChild($root);
			$root->setAttribute('version','2.0');

			//create the channel element
			$channel = $doc->createElement("channel");
			$channel = $root->appendChild($channel);

			$elements = array();
			$elements["title"] = "ZBlog Recent Entries";
			$elements["link"] = "http://localhost/rss";
			$elements["description"] = "Feed containing recent entries from the ZBlog sample implementation.";
			$elements["language"] = "en-us";
			$elements["copyright"] = "Copyright 2007 Zend technologies Inc";
			$elements["docs"] = "http://localhost/rss";
			
			foreach ($elements as $elementname => $elementvalue)
			{
				$elementname = $doc->createElement($elementname);
				$elementname = $channel->appendChild($elementname);
				$elementname->appendChild($doc->createTextNode($elementvalue));
			}

			//clear the array
			unset($elements);


			//loop through each item and add its elements to the tree
			foreach ($recentEntries as $recentEntry)
			{
				//create the item element
				$item = $doc->createElement("item");
				$item = $channel->appendChild($item);

				foreach ($recentEntry as $elementname => $elementvalue)
				{
					$elementname = $doc->createElement($elementname);
					$elementname = $item->appendChild($elementname);
					$elementname->appendChild($doc->createTextNode($elementvalue));
				}
			}

			return  $doc->saveXML();
		} catch (\Exception $e) {
			Logger::getInstance()->writeLog($e->getMessage(), 'ERR');
		}
	}
}