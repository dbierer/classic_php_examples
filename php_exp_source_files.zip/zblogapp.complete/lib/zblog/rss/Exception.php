<?php

namespace zblog\rss;

/**
 * ZBlog/Rss/Exception.php
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog Rss Exception Class
 *
 */
class Exception extends \zblog\Exception 
{
}