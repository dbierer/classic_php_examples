<?php

namespace zblog\controller;

class AuthenticationManager
{
	
	public function __invoke() {
	    if (!isset($_SESSION['isLoggedIn'])) {
    		if (isset($_GET['useHttpAuth'])) {
    			header('Location:' . URL_HOME . '/login/http');
    			
    		} else {
    			header('Location:' . URL_HOME . '/login');	    			
    		}
    		exit;
    	}			
	}
	
}