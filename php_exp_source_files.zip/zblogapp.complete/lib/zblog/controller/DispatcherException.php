<?php

namespace zblog\controller;

/**
 * ZBlog/Controller/Exception.php
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog Dispatcher Exception Class
 *
 */
class DispatcherException extends \zblog\Exception 
{
 	public function __construct($message = null, $code = 0)
     {
         echo 'ciao'.$message;
         //parent::__construct($message, $code);
     }	
}