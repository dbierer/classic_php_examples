<?php

/**
 * ZBlog/Data/Exception.php
 * 
 * ZBlog Data exception class
 * 
 * @author Zend Technologies Inc.
 */


class Exception extends \zblog\Exception
{
}