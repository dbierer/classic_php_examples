<?php

namespace zblog\util;

/**
 * zblog/util/Exception.php
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog Utils Exception Class
 *
 */
class Exception extends zblog\Exception 
{
}