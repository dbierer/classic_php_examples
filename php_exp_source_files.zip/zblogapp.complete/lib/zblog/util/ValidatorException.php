<?php

namespace zblog\util;

/**
 * ZBlog/Utils/ValidatorException.php
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog Utils Exception Class
 *
 */
class ValidatorException extends \zblog\util\Exception 
{
}