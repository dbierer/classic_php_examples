<?php

namespace zblog\loader;


class Autoloader
{
	
	protected static $_loader = null;
	
	public function loadClass($class, $throwException = true)
	{
		if (class_exists($class, false)) {
			return true;
		}
		$path = str_replace('\\', DIRECTORY_SEPARATOR, $class) . '.php';
		if ($path[0] === '/') {
			$path = substr($path, 1);
		}
		include_once $path;
		if (!class_exists($class)) {
			if ($throwException) {
				throw new Exception('Unable to load class: ' . $class);
			}
			return false;
		}
		return true;
	}
	
	/**
	 * @return Autoloader
	 */
	
	public static function getInstance()
	{
		if (self::$_loader === null) {
			self::$_loader = new static();
			spl_autoload_register(array(self::$_loader, 'loadClass'));
		}
		return self::$_loader;
	}
	
}