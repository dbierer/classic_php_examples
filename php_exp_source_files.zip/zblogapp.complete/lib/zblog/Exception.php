<?php

namespace zblog;

/**
 * ZBlog/Exception.php
 * 
 * @author Zend Technologies Inc.
 */

/**
 * ZBlog Exception Class
 *
 */
class Exception extends \Exception 
{
}