<?php
function dirscan($path) {
	static $output = '';
	$count = 1;
	$list = glob($path . '/*');
	foreach ($list as $item) {
		if (is_dir($item)) {
			$output .= sprintf("<tr bgcolor='yellow'><td>%03d</td><td colspan=2>%s</td></tr>", $count++, $item);
			dirscan($item);
		} else {
			$size 	= filesize($item);
			$lines 	= count(file($item));
			$output .= sprintf("<tr><td>%20s</td><td>%06d</td><td>%04d</td></tr>", basename($item), $size, $lines);
		}
	}
	return $output;
}
// note: shows base directory from project zblogappwork
$path	= '../../../zblogappwork';
$result = dirscan($path);
echo "Base Directory: $path<br />\n";
echo '<table>';
echo $result;
echo "</table>\n";
