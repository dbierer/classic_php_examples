<?php
$contents = file_get_contents('myfile.txt');
echo 'Before: <hr />' . $contents . '<hr />';
echo 'After: <hr />' .preg_replace(array('/c\+\+/i', '/java/i'), 'PHP', $contents);