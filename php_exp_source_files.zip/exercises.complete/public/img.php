<?php
$contents = file_get_contents('http://www.flickr.com/photos/');

preg_match_all('/<a href=\"([^\"]*)\"[^>]*><img src=\"([^\"]*)\".*class=\"pc_img\"[^>]*><\/a>/', $contents, $matches);

$urls = $matches[1];
$pics = $matches[2];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>Flickr most recent images</title>
	</head>
	<body>
	<table>
		<tr>
			<th>Image</th>
			<th>Url</th>
		</tr>
<?php for($i=0;$i<count($urls); $i++):?>
		<tr>
			<td><img src="<?php echo $pics[$i]; ?>"/></td>
			<td><a href="http://www.flickr.com<?php echo $urls[$i]?>">http://www.flickr.com<?php echo $urls[$i]?></a></td>
		</tr>
<?php endfor; ?>
	</table>
	</body>
</html>
