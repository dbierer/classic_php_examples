<?php
$list = array('www.bbc.co.uk',
			  'news.bbc.co.uk',
			  'www.bbc.co.uk/worldservice',
			  'badurl',
			  'badurl/test');
$pattern = '/^(\w{2,4}\.)+\w{2,4}(\/\w+)?$/i';
echo '<hr />';
echo 'Pattern: ' . htmlentities($pattern) . '<br />' . PHP_EOL;
echo '<hr />';
echo '<table>';
foreach ($list as $url) {
	echo '<tr>';
	echo '<th>' . $url . '</th>';
	echo '<td>';
	echo (preg_match($pattern, $url) > 0) ? 'Matches' : 'Does not match';
	echo '</td>';
	echo '</tr>' . PHP_EOL;	
}
echo '</table>' . PHP_EOL;
