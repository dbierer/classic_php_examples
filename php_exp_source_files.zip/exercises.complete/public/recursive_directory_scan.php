<?php
function recursiveScan($dir) {
	// get a list of files in this directory
	static $output = '';
	$list = glob($dir . '/*');
	// loop through list
	foreach ($list as $item) {
		// if directory print and call this function again
		if (is_dir($item) && $item != '.' && $item != '..') {
			$output .= '<span style="background-color: gray;">';
			$output .= $item;
			$output .= '</span>';
			$output .= recursiveScan($item);
		// otherwise output info as a table row
		} else {
			$output .= '<li>';
			$output .= '<a href="' . basename($item) . '">' . basename($item) . '</a>';
			$output .= '</li>';
		}
	}
	return $output;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Recursive Directory Scan</title>
<style>
TD {
	font: 10pt helvetica, sans-serif;
	border: thin solid black;
	color: gray;
	text-align: right;
	}
TH {
	font: bold 10pt helvetica, sans-serif;
	color: green;
	border: thin solid black;
	text-align: left;
	}
</style>
</head>
<body>
<h1>Web Services Demo</h1>
<ul>
<?php echo recursiveScan('.'); ?>
</ul>
</body>
</html>
