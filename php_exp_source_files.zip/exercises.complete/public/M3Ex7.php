<?php
$header = 'Authorization: Basic '.base64_encode('administrator:password')."\r\n"; 
$header .= 'Cookie: '.session_name().'='.md5(microtime())."\r\n"; 
$context = stream_context_create( 
	array ( 
		'http' => 
			array( 
				'header' => $header 
			) 
	) 
); 

$url = 'http://' . $_SERVER['HTTP_HOST'] . '/exercisescomplete/admin/?useHttpAuth=1';
$fh = fopen($url, 'r', null, $context); 
$content = ''; 
while (!feof($fh)) { 
	$content .= fread($fh, 1024); 
} 
fclose($fh); 
echo strip_tags($content);
