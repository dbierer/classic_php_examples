<?php
// Initialize Variables
$message = '';
$fn		 = '';
$dir 	 = __DIR__ . DIRECTORY_SEPARATOR . "uploads" . DIRECTORY_SEPARATOR;

// Check to see if OK button was pressed
if ( isset($_POST['OK'])) {

	// Check to see if upload parameter specified
	if ( $_FILES['upload']['error'] == UPLOAD_ERR_OK ) {

		// Check to make sure file uploaded by upload process
		if ( is_uploaded_file ($_FILES['upload']['tmp_name'] ) ) {
			
			// Capture filename
			$fn = $_FILES['upload']['name'];

			// Sanitize the filename
			// Note "i" (case insensitive) and "u" UTF-8 modifiers
			$fn = preg_replace('/[^a-z0-9-_.]/iu', '_', $fn);
			
			// Move image to ../backup directory
			$copyfile = $dir . $fn;
		
			// Copy file
			if ( move_uploaded_file ($_FILES['upload']['tmp_name'], $copyfile) ) {
				$message .= "<br>Successfully uploaded file $copyfile\n";
			} else {
				// Trap upload file handle errors
				$message .= "<br>Unable to upload file " . $_FILES['upload']['name'];
			}
			
		} else {
			// Failed security check
			$message .= "<br>File Not Uploaded!";
		}
		
	} else {
		// No photo file; return blanks and zeros
		$message .= "<br>No Upload File Specified\n";
	}
}	

// Scan directory
$list = glob($dir . '*');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Upload File</title>
<style>
TD {
	font: 10pt helvetica, sans-serif;
	border: thin solid black;
	}
TH {
	font: bold 10pt helvetica, sans-serif;
	border: thin solid black;
	}
</style>
</head>
<body>
<h1>Upload File</h1>
This is an example of a file upload script. Select a file to upload by using the browse
button below and it will be uploaded into the exercisescomplete/uploads directory.
A complete directory listing of that location can be seen below...<br><br>

<form name="Upload" method=POST enctype="multipart/form-data">
<input type=file method=POST enctype="multipart/form-data" size=50 maxlength=255 name="upload" value="" />
<br><input type=submit name="OK" value="OK" />
</form><br>
<table cellspacing=4>
<tr><th>Filename</th><th>Last Modified</th><th>Size</th></tr>
<?php
if (isset($list)) {
	foreach ($list as $item) {
		echo "<tr><td>$item</td>";
		echo "<td>" . date ("F d Y H:i:s", filemtime($item)) . "</td>";
		echo "<td align=right>" . filesize($item) . "</td>";
		echo "</tr>\n";
	}
}
echo "</table>\n";
phpinfo(INFO_VARIABLES);
?>
</body>
</html>
