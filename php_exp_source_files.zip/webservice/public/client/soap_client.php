<?php
ini_set('soap.wsdl_cache_enabled', '0'); 

$wsdl = 'http://' . $_SERVER['HTTP_HOST'] . '/webservice/server/autowsdl.php';
$client = new SoapClient($wsdl);

$debug = false;

if ($debug) {
    $cookie = array(
        'start_debug' => '1',
        'debug_host' => $_SERVER['SERVER_ADDR'],
        'use_remote' => '1',
        'debug_port' => '10137',
        'debug_stop' => '1',
        'debug_session_id' => '123456',
        'debug_fastfile' => '1',
        'original_url' => 'http://zf.sandbox.dev'
    );
    foreach ($cookie as $key => $value) {
        $client->__setCookie($key, $value);
    }
}

echo "<h3>Soap Client</h3><hr />\n";
echo "<br />WSDL: $wsdl";
echo "<p>";
try {
	echo "<br />\n3 + 5 = " . $client->add(3, 5);
	echo "<br />\n8 - 4 = " . $client->sub(8, 4);
	echo "<br />\n4 * 6 = " . $client->__call('mul', array(4, 6));
	echo "<br />\n3 / 2 = " . $client->div(3, 2);
	echo "<br />\n3 / 0 = ";
	echo $client->div(3, 0);
}
catch (SoapFault $e) {
    echo $e->getMessage();
}
echo "</p>\n";
