<?php
include 'Calc.php';
$wsdl = 'http://' . $_SERVER['HTTP_HOST'] . '/webservice/server/autowsdl.php';
$server = new SoapServer($wsdl);
$server->setClass('Calc');
$server->handle();