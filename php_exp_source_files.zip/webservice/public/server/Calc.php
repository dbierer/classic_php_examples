<?php
class Calc {
	/**
	 * @name add
	 * @param float $a
	 * @param float $b
	 * @return float
	 */
    public function add($a, $b) {
        return $a + $b;
    }
    
	/**
	 * @name sub
	 * @param float $a
	 * @param float $b
	 * @return float
	 */
    public function sub($a, $b) {
        return $a - $b;
    }
    
	/**
	 * @name mul
	 * @param float $a
	 * @param float $b
	 * @return float
	 */
    public function mul($a, $b) {
        return $a * $b;
    }
    
	/**
	 * @name div
	 * @param float $a
	 * @param float $b
	 * @return float
	 */
    public function div($a, $b) {
        if ($b == 0) {
            throw new SoapFault('Server', 'Division by Zero!');
        }
        return $a / $b;
    }
}