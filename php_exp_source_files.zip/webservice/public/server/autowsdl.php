<?php
include 'Calc.php';

require_once 'AutoDiscover.php';

$uri = 'http://' . $_SERVER['HTTP_HOST'] . '/webservice/server/';

$autodiscover = new Zend_Soap_AutoDiscover(true, $uri);
$autodiscover->setClass('Calc');

header ("Content-Type:text/xml");
echo $autodiscover->toXml();