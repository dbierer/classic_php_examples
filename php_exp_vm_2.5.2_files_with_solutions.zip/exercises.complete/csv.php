<?php

$quotesUrl = 'http://download.finance.yahoo.com/d/quotes.csv?s=INDU,^IXIC,^TNX,^GSPTSE,MSFT&f=snl1d1t1c1ohg';

$fp = fopen($quotesUrl, 'r');

$quotes = array();

while ($line = fgets($fp))
{
	$quoteArr = explode(',', $line);
	foreach($quoteArr as $k => $value)
	{
		$quoteArr[$k] = trim($value, '"');
	}
	$quotes[] = $quoteArr;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title></title>
	</head>
	<body>
		<h1>Yahoo! Quotes</h1>
		<table>
		<tr>
			<th>Index</th>
			<th>Description</th>
			<th>Value</th>
			<th>Date - time</th>
			<th>Change</th>
			<th>Low</th>
			<th>High</th>
		</tr>
		
		<?php foreach($quotes as $quote): ?>
		<tr>
			<td><?php echo $quote[0] ?></td>
			<td><?php echo $quote[1] ?></td>
			<td><?php echo $quote[2] ?></td>
			<td><?php echo $quote[3] . ' ' .$quote[4] ?></td>
			<td><?php echo $quote[5] ?></td>
			<td><?php echo $quote[6] ?></td>
			<td><?php echo $quote[7] ?></td>
		</tr>
		<?php endforeach; ?>	
		</table>
	</body>
</html>