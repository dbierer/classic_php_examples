<?php
class GoogleRestClient {
    const URI = 'https://ajax.googleapis.com/ajax/services/search/web?v=1.0';
    
    private $response;
    
    public function search($query) {
        $url = $this->prepareUrl($query);
        
        $response = file_get_contents($url);
        
        $this->response = json_decode($response);
    }    
    
    private function prepareUrl($query) {
        return self::URI . '&q=' . rawurldecode($query);
    }

    public function isValid() {
        return ($this->response->responseStatus == '200');
    }
    
    public function getTopResultTitle() {
        $topResult = $this->response->responseData->results[0];
        
        return $topResult->titleNoFormatting;
    }
    
    public function getTopResultContent() {
        $topResult = $this->response->responseData->results[0];
        
        return $topResult->content;
    }
    
    public function getEstimatedResultCount() {
        return $this->response->responseData->cursor->estimatedResultCount;
    }
}

$client = new GoogleRestClient();
$client->search('Zend');

echo $client->getTopResultTitle();
echo "<br />\n";
echo $client->getTopResultContent();
echo "<br />\n";
echo 'Estimated result count: ' . $client->getEstimatedResultCount();

