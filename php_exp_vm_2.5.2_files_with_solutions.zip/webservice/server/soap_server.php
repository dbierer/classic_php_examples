<?php
ini_set("soap.wsdl_cache_enabled", "0"); 

require_once 'Calc.php';

$server = new SoapServer('http://webservice/server/autowsdl.php');
$server->setClass('Calc');

$server->handle();