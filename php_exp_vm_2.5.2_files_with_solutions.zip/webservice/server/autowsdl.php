<?php
include 'Calc.php';

require_once 'Zend/Soap/AutoDiscover.php';

$uri = 'http://webservice/server/soap_server.php';

$autodiscover = new Zend_Soap_AutoDiscover(true, $uri);
$autodiscover->setClass('Calc');

header ("Content-Type:text/xml");
echo $autodiscover->toXml();