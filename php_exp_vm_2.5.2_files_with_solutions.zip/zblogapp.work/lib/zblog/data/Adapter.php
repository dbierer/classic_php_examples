<?php

namespace zblog\data;

use zblog\log\Logger;

/**
 * ZBlog/Adapter.php 
 * 
 * File contains the ZBlog_Data class.
 * Creates a connection on instantiation
 * 
 * @author Zend Technologies Inc.
 * @copyright 2008
 */

/**
 * Adapter
 * Class contains methods for manipulating the BLOG data stored
 * in SQLite database.
 *
 */
class Adapter
{
		
	private static $dbAdapter;
	private $_pdo;
	private $_queries = array();
	
	/**
	 * We make sure that only one instance of the database is passed around
	 *
	 * @return PDO
	 */
	
	public static function getAdapter()
	{
		if (self::$dbAdapter === NULL) {

			try {
				$db = 'sqlite:'. DB_PATH . DB_NAME;

				self::$dbAdapter = new Adapter(new \PDO($db));
				self::$dbAdapter->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
				
			} catch (\Exception $e) {
			  	Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );

    		}
		}
		
		return self::$dbAdapter;
	}	
	
	private function __construct(\PDO $pdo)
	{
		$this->_pdo = $pdo;
	}
	
	public function __call($method, $vars = array())
	{
		if (IN_DEV) {
			$time = microtime();
		}
		try {
			$return =  call_user_func_array(array($this->_pdo, $method), $vars);
		} catch (Exception $e) {
			throw new Exception($e->getMessage());
		}
		if (IN_DEV) {
			$elapsed = microtime() - $time;
			switch ($method) {
				case 'query':
				case 'exec':
					if ($vars[0] instanceof \PDOStatement ) {
						$this->_queries[] = sprintf("Executing prepared statement %f seconds: (%s)", $elapsed, $vars[0]);
					} else {
						$this->_queries[] = sprintf("Query %f seconds: (%s)", $elapsed, $vars[0]);
					}
					break;
				case 'quote':
					$this->_queries[] = sprintf("Quoting %f seconds: (%s)", $elapsed, $vars[0]);
					break;
				case 'beginTransaction':
					$this->_queries[] = sprintf("Beginning Transaction %f seconds: (%s)", $elapsed, $vars[0]);
					break;
				case 'rollback':
					$this->_queries[] = sprintf("Rolling Back Transaction %f seconds: (%s)", $elapsed, $vars[0]);
					break;
				case 'commit':
					$this->_queries[] = sprintf("Committing Transaction %f seconds: (%s)", $elapsed, $vars[0]);
					break;
				case 'prepare':
					$this->_queries[] = sprintf("Committing Transaction %f seconds: (%s)", $elapsed, $vars[0]);
					break;
				default:
					$this->_queries[] = sprintf("%s %f seconds: (%s)", $method, $elapsed, implode(', ', $vars));
					break;
			}
			$this->_elapsedTime = microtime();
		}
		return $return;
	}
	
	/**
	 * Returns a list of all the operations that have occurred so far
	 *
	 * @return array
	 */
	
	public function getAllOperations()
	{
		return $this->_queries;
	}
}