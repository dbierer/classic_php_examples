<?php

/**
 * ZBlog/View/Exception.php
 * 
 * @author Zend Technologies Inc.
 */
namespace zblog\view;

/**
 * ZBlog View Exception Class
 *
 */
class Exception extends \zblog\Exception 
{
}