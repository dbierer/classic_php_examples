<?php

class View_Helper_Searchresults
{

	public $view;
		
	
	public function load() 
	{
		$urlHome = $this->view->getVar('urlHome');
		$entries = $this->view->getVar('entries');
		$query 	 = $this->view->getVar('query');
		
		// TODO: In the case where $entries is a valid array output the search
		//       results one per line. Otherwise, output a no results message.
		//       Hint: The return value should be a string containing the HTML.
		//       Hint: Remember to escape output!
		
        return  $entryDisplay; 
    }
}