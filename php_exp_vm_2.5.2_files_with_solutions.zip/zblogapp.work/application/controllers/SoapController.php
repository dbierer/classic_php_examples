<?php

namespace controllers;

use models;

class SoapController extends \zblog\controller\ControllerAbstract 
{
	public function indexAction()
	{
		header('Location: http://'.$_SERVER['SERVER_NAME'].'/soap/wsdl/');
	}

	public function wsdlAction()
	{
		require_once 'Zend/Soap/AutoDiscover.php';
		
		$uri = 'http://'.$_SERVER['SERVER_NAME'].'/soap/server/';
		
		$autodiscover = new \Zend_Soap_AutoDiscover(true, $uri);
		/*
		 * TODO: publish the details of the model\Soap class 
		 */
		
		header ("Content-Type:text/xml");
		/*
		 * TODO: output the generated WSDL file 
		 */
		
		exit;
	}
	
	public function serverAction()
	{
		/*
		 * TODO: Create an instance of the SoapServer class (Hint: remember to
		 * pass the URL of the wsdl action above) register the model\Soap class
		 * and finally direct the SoapServer to handle the incoming request.
		 */
		
		exit;
	}
	
	public function clientAction()
	{
		/*
		 * TODO: Create an instance of the SoapClient class (Hint: remember to
		 * pass the URL of the wsdl action above) and call the getArticles() method.
		 * Finally, remember to utf8_decode() any encoded data before output!
		 */

		exit;
	}
	
}