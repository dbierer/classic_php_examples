<?php

/**
 * This file contains configuration for the ZBlog Application
 * 
 * @author Zend Technologies Inc.
 */

/**
 * ---------------------------------
 * General application configuration
 * ---------------------------------
 */

/**
 * Application name
 */
const APP_NAME = 'ZBlog (Search)';

/**
 * Application copyright
 */
const APP_COPYRIGHT = '&copy; 2007 Zend Technologies Inc.';

/**
 * ZBlog homepage url
 *
 */
const URL_HOME = '';

/**
 * ZBlog Styles url
 */
define( 'URL_STYLES', URL_HOME . '/styles/styles.css' );

/**
 * Physical path to the application
 *
 */
define( 'APP_PATH', realpath(dirname(__FILE__).DIRECTORY_SEPARATOR.'..').DIRECTORY_SEPARATOR );

/**
 * ZBlog application lib path
 */
define( 'LIB_PATH', APP_PATH, 'lib' . DIRECTORY_SEPARATOR );

/**
 * ZBlog Log file path
 */
define( 'LOG_PATH', APP_PATH . 'data' . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR );

/**
 * ZBlog Log file base name
 * Data/time of logging is prepended to this name
 */
const LOG_FILENAME = 'zblog.log';

/**
 * Entry log for L2Ex1
 * Date/time of logging is prepended to name
 */
const ENTRY_LOG = 'entry.log';

/**
 * ------------------------------
 * Database configuration section
 * ------------------------------
 */

/**
 * Path to SQLite datastore
 *
 */
define( 'DB_PATH', APP_PATH . 'data' . DIRECTORY_SEPARATOR );

/**
 * Database name
 */
const DB_NAME = 'blogdb.sqlite';

define('IN_DEV', getenv('IN_DEV'));

