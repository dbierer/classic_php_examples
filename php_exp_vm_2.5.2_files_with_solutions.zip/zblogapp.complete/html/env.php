The current environment is: 
<?php
echo getenv('IN_DEV');