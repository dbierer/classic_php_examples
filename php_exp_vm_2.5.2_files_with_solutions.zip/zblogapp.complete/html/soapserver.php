<?php

class myClass {
	
	/**
	 * This is Kevin's function
	 *
	 * @param string $param
	 * @return string
	 */
	function myFunction($param) {
		return $param;
	}
}

$soap = new SoapServer('Test.wsdl');
$soap->setClass('myClass');
$soap->handle();