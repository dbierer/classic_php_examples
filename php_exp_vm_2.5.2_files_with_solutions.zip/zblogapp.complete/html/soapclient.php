<?php

$soapClient = new SoapClient('http://192.168.175.141/zblog/Test.wsdl');

echo $soapClient->myFunction('Hello');