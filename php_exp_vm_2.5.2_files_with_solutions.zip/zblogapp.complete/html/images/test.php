<?php
echo "I'm in the image directory!";
