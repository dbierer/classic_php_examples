<pre><?php

$sql = <<<EOQ
SELECT entry_id, title, modified 
FROM blogentries 
ORDER BY modified DESC
LIMIT 0,5
EOQ;

$pdo = new PDO('sqlite:/usr/local/projects/zblog/data/blogdb.sqlite');

$stmt = $pdo->prepare($sql);
if ($stmt->execute()) {
	while (($row = $stmt->fetch()) !== false) {
		var_dump($row);
	}
}