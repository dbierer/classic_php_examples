<?php

namespace zblog\util;

use \zblog\log\Logger;

/**
 * zblog/util/Validators.php
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog_Validator Class
 * 
 * Provides static methods for validating and filtering input data
 */
class Validators {

	const USERNAME_MIN_LENGTH = 6;
	const USERNAME_MAX_LENGTH = 45;
	const PASSWORD_MIN_LENGTH = 6;
	const PASSWORD_MAX_LENGTH = 45;
	const TITLE_MIN_LENGTH = 1;
	const TITLE_MAX_LENGTH = 120;
	const COMMENT_MIN_LENGTH = 1;
	const COMMENT_MAX_LENGTH = 255;
	const BLOGENTRY_MIN_LENGTH = 1;
	const BLOGENTRY_MAX_LENGTH = 2000;
			
	/**
	 * Validates the input username 
	 * Checks for string length and alphanumneric chars
	 *
	 * @param string $userName
	 * @return boolean
	 */
	public static function validUserName($userName) {
		
		try{
			//Check length
			if (!preg_match("/^.{" . self::USERNAME_MIN_LENGTH . "," . self::USERNAME_MAX_LENGTH . "}$/", $userName)) {
				return false;
			} 
			//Check alphanumeric
			if (!preg_match("/^[A-z0-9]+$/", $userName)) {
			
				return false;
			}
			return true;
			
		} catch (ValidatorException $e) {
			Logger::getInstance()->writeLog($e->getMessage(), 'ERR');
		}
	}
	
	/**
	 * Validates valid password format
	 * Checks string length and alphanumeric chars 
	 * L5Ex2: Implement the function so that it checks against a regular expression
	 * 
	 * @param string $password
	 * @return boolean
	 */
		public static function validPassword($password) {
		return true;
	}
	
	
	/**
	 * Checks for valid title length
	 *
	 * @param string $title
	 * @return boolean
	 */
	public static function validTitleLength($title) {
			//Check length
			if (!preg_match("/^.{" . self::TITLE_MIN_LENGTH . "," . self::TITLE_MAX_LENGTH . "}$/", $title)) {
				return false;
			} 
			return true;
	}
	
	/**
	 * Checks valid length for blog entries
	 *
	 * @param string $entry
	 * @return boolean
	 */
	public static function validEntryLength($entry) {
			//Check length
			if (!preg_match("/^.{" . self::BLOGENTRY_MIN_LENGTH . "," . self::BLOGENTRY_MAX_LENGTH . "}$/", $entry)) {
				return false;
			} 
			return true;
	}

	/**
	 * Checks valid length for comment
	 *
	 * @param string $comment
	 * @return boolean
	 */
	public static function validCommentLength($comment) {
			//Check length
			if (!preg_match("/^.{" . self::COMMENT_MIN_LENGTH . "," . self::COMMENT_MAX_LENGTH  . "}$/", $comment)) {
				return false;
			} 
			return true;
	}

	/**
	 * Checks if valid email address input
	 *
	 * @param string $email
	 * @return boolean
	 */
	public static function validEmail($email) {
			$strict = false;
			$regex = $strict?'/^([.0-9a-z_-]+)@(([0-9a-z-]+\.)+[0-9a-z]{2,4})$/i' : '/^([*+!.&#$�\'\\%\/0-9a-z^_`{}=?~:-]+)@(([0-9a-z-]+\.)+[0-9a-z]{2,4})$/i';
			//Check length
			if (!preg_match($regex, $email)) {
				return false;
			} 
			return true;
	}	
	
	public function __construct()
	{
		throw new ValidatorException("Class only has static functionality");
	}
	
	
}