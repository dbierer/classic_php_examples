<?php

namespace zblog\util;

use \zblog\log\Logger;

/**
 * ZBlog/Utils.php
 * 
 * @author Zend Technologies Inc.
 */

/**
 * ZBlog Utils Class
 *
 */
class Utils
{
	
	public static function formatText( $inputText = null)
	{
		if ($inputText != null) {
			try {
				
				
				//handle bold text
				$inputText = preg_replace('/{{{(.*?)}}}/','<span class="bold">$1</span>', $inputText);
				
				//handle H2 text
				$inputText = preg_replace('/{{(.*?)}}/','<span class="header2">$1</span>', $inputText);
				
				//handle H1 text
				$inputText = preg_replace('/{(.*?)}/','<span class="header1">$1</span>', $inputText);
				
				//handle url links
				$inputText = preg_replace('/\[(.*?)\|(.*?)\]/', '<a href="$2" target="_blank">$1</a>', $inputText);
			
				//Handle linebreaks
				$inputText = nl2br($inputText);
				
			} catch (Exception $e) {
				Logger::getInstance()->writeLog($e->getMessage(), 'INFO');
			}
		}
		return $inputText;
	}
}