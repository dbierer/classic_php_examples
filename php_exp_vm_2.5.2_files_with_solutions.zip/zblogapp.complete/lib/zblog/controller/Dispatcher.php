<?php

namespace zblog\controller;

use zblog\loader;

use zblog\log\Logger;

/**
 * ZBlog/Dispatcher.php
 * 
 * @author Zend Technologies Inc.
 */

/**
 * ZBlog_Dispatcher Class
 * Provides methods to route request from the UI to the 
 * appropriate controller and assigns view to the request
 */

class Dispatcher
{	
	protected $_viewScript = 'index/index.phtml';
	
	protected $_controllerName = 'Index';
	
	protected $_actionName = 'index';
	
	protected $_params = array();
	
	protected $_requestType = 'GET';
	
	public function getViewScript()
	{
		return $this->_viewScript;
	}
	
	public function getControllerName()
	{
		return $this->_controllerName;
	}
	
	public function getActionName()
	{
		return $this->_actionName;
	}
	
	public function getParams()
	{
		return $this->_params;
	}

	/**
	 * Get controller for this request
	 *
	 */
	private function _dispatchHelper()
	{
		$requestPath = dirname($_SERVER['SCRIPT_NAME']);
		$requestUri = $_SERVER['REQUEST_URI'];
		if (($pos = strpos($requestUri, '?')) !== false) {
			$requestUri = substr($requestUri, 0, $pos - 1);
		}
		
		$start = $requestPath == '/' ? 1 : strlen($requestPath);
		$request = substr($requestUri, $start);
		if ($request === false) {
			$params = array();
		} else {
			$params = explode( "/", $request );
		}
		
		
		if (count($params) > 0) {
			$controllerName = strtolower( array_shift( $params ) );
			if (!ctype_alnum($controllerName)) {
				throw new DispatcherException('Invalid controller name: ' . $controllerName);
			}
			$this->_controllerName = ucfirst( $controllerName );
		}
		
		//Get action name
		
		if (count($params) > 0) {
			$actionName = array_shift( $params );
			if (!ctype_alnum($actionName)) {
				throw new DispatcherException('Invalid action name: ' . $actionName);
			}
			//Get request action
			$this->_actionName = $actionName;
		}

		$key = null;
		$reqParams = array();
		foreach ($params as $value) {
			if ($key === null) {
				$key = $value;
			} else {
				$reqParams[$key] = $value;
				$key = null;
			}
		}
		
		$this->_params = array_merge($reqParams, $_GET);

		if(isset($_POST['REMOTE_ADDR'])) {
			unset($_POST['REMOTE_ADDR']);
		}
		
		if(isset($_POST['SCRIPT_NAME'])) {
			unset($_POST['SCRIPT_NAME']);
		}
		
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$this->_params = array_merge($this->_params, $_POST);
			$this->_requestType = 'POST';
		}

		//Set View Script
		$this->_viewScript = APP_PATH
						   . 'application'
						   . DIRECTORY_SEPARATOR
						   . 'views'
						   . DIRECTORY_SEPARATOR
						   . 'scripts'
						   . DIRECTORY_SEPARATOR
						   . strtolower($this->_controllerName)
						   . DIRECTORY_SEPARATOR
						   . $this->_actionName
						   . '.phtml';

		
	}
	
	/**
	 * Dispatches the request to the appropriate 
	 * controller, depending on the called script,
	 * action and url parameters.
	 *
	 */
	public function dispatch()
	{
		
		//Get Controller

		$this->_dispatchHelper();
		$controllerClass = '\controllers\\'.$this->_controllerName . 'Controller';
		$classExists = \zblog\loader\Autoloader::getInstance()->loadClass(
			$controllerClass ,
			false
		);
	    if (!$classExists) {
	    	$err_msg = 'Controller not found ...';
	    	echo '<h2>An Error Occured!</h2>';
	    	echo $err_msg;
	    	throw new DispatcherException( $err_msg );
	    }
	    
	            //Set view script
        $view = new \zblog\view\View();
        $view->setScript( $this->_viewScript );
       
        $controllerObj = new $controllerClass();
        $controllerObj->view = $view;
	   
        //Get Action
        $actionName = $this->_actionName . 'Action';
        if (is_callable(array($controllerObj, $actionName)) == false) {
        	$err_msg = 'Invalid Action specified ...';
        	echo '<h2>An Error Occured!</h2>';
        	throw new Exception( $err_msg );
        }
        
        $view->setRequestParams($this->_params);        
        
        // Run action
		if (is_callable($controllerObj->preDispatchCall)) {
			$call = $controllerObj->preDispatchCall;
			$call();
		}
		        
        $controllerObj->$actionName();
        
		if (is_callable($controllerObj->postDispatchCall)) {
			$call = $controllerObj->postDispatchCall;
			$call();
		}
		
		$view->render();
	}
	
}