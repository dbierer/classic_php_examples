<?php

namespace zblog\controller;

abstract class ControllerAbstract 
{
	public $preDispatchCall = null;
	public $postDispatchCall = null;
	
	abstract public function indexAction();
}