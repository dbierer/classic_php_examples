<?php

namespace zblog\loader;

class Exception extends \zblog\Exception {}