<?php

namespace zblog\loader;

require_once 'Autoloader.php';

use zblog\log;

use \zblog\log\Logger;

class LoggingAutoloader extends Autoloader
{

	public function loadClass($class, $throwException = true)
	{
		
		$return = parent::loadClass($class, $throwException);
		$logger = Logger::getInstance();
		
		$success = $return ? ' succeeded' : ' failed';
		
		$logger->writeLog(
			'Loading class '
			. $class
			. $success
		);
		return $return;
	}

	
}