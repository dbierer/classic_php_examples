<?php
namespace zblog\view;

/**
 * ZBlog/View/Exception.php
 * 
 * @author Zend Technologies Inc.
 */

/**
 * ZBlog View Exception Class
 *
 */
class Exception extends \zblog\Exception 
{
}