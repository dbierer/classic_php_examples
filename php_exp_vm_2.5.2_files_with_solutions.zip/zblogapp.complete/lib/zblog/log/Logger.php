<?php

namespace zblog\log;

/**
 * ZBlog/Logger.php
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog_Logger
 *
 * Logs all messages to a log file
 * path to log file defined in configs
 * 
 */

class Logger
{
	
	private static $loggerinstance;
	
	/**
	 * Retrieves an instance of the logger class
	 *
	 * @return ZBlog_Logger
	 */
	
	public static function getInstance()
	{
		if (self::$loggerinstance === NULL)
		{
			self::$loggerinstance = new Logger();
		}
		
		return self::$loggerinstance;
	}
	
	
	/**
	 * Logs messages to log file
	 *
	 * @param string $message
	 * @param string $level
	 */
	public function writeLog($message, $level = 'INFO') 
	{
		$logFile = LOG_PATH . date( 'Ymd') . LOG_FILENAME;		
		error_log( date('His') . " - " . $message . "\r\n", 3, $logFile );
	}
	
 	/**
 	 * L2Ex1: Writing to files
 	 * logs an entry view to the ENTRY_LOG file
 	 * 
 	 * @param int entryId
 	 * @param string $entryTitle
 	 */
 	public function logEntry($entryId, $entryTitle)
 	{
 		$logFile = LOG_PATH . date( 'Ymd') . ENTRY_LOG;
 		$fp = fopen($logFile, 'a');
 		
 		 //L3Ex4: add locking to file
 		flock($fp, LOCK_EX);
 		
 		//L2Ex1: Writing to files
 		fwrite($fp, date('His')."\t".$_SERVER['REMOTE_ADDR']."\t$entryId\t$entryTitle"); 
 		fwrite($fp, PHP_EOL);
 		
 		 //L3Ex4: add locking to file
 		flock($fp, LOCK_UN);
 		fclose($fp);
 	}
}