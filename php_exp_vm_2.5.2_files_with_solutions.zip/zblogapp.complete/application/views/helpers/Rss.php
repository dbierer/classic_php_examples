<?php

class View_Helper_Rss
{

	public $view;
	
	public function load() 
	{
		$rssFeed = $this->view->getVar('rssFeed');
		$feedHtml = $rssFeed;
		
		return $feedHtml;
	}
}