<?php

class View_Helper_Header 
{

	public $view;
		
	public function load() 
	{
		if (isset($_SESSION['isLoggedIn'])) {
			$userName = $_SESSION['realName'];
		} else {
			$userName = 'Guest';
		}
		
		$applicationName = $this->view->getVar('applicationName').((IN_DEV)?' - DEV ENV':'');
		$urlHome 			= $this->view->getVar('urlHome');
		
		$welcome = 'Welcome <span class="bold">' . $userName . '</span>';
		
		if ($userName != 'Guest') {
			
			$welcome .= ' - <a href="' . $urlHome . '/admin">Manage</a> | <a href="' . $urlHome . '/logout">logout</a>';	
		} else {
			$welcome .= ' - <a href="' . $urlHome . '/login">login</a>';	
		}
		
        $headerHtml = <<<EOQ
<div id="header">
	
	<a href="/">Home</a> | $welcome
    <h1>$applicationName</h1>    	
</div>
EOQ;

        return $headerHtml;
        
    }
}