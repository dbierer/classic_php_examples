<?php

class View_Helper_Adminmenu 
{

	public $view;
		
	public function load() 
	{
		$urlHome = $this->view->getVar('urlHome');
		
        $adminMenuHtml = <<<EOQ
			<ul>
				<li><a href="$urlHome/admin">Admin Home</a> </li>
 				<li><a href="$urlHome/admin/changepassword">Change password</a> </li>
 				<li><a href="$urlHome/admin/logs">Logs</a> </li>
			</ul>
			
			<h3>Blog entries</h3>
			<ul>
				<li><a href="$urlHome/admin/newentry">Add New Entry</a></li>
			</ul>
			<h3>Comments</h3>
			<ul>	
				<li><a href="$urlHome/admin/managecomments">Manage comments</a></li>	
			</ul>	
			
EOQ;

        return $adminMenuHtml;
        
    }
}