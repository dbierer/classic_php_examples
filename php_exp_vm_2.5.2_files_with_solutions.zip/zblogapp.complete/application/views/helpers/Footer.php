<?php

class View_Helper_Footer 
{

	public $view;
		
	public function load() 
	{
		
		$urlHome = $this->view->getVar('urlHome');
		
        $footerHtml = <<<EOQ
<div class="clear"></div>
<div id="footer">
	&copy; 2007, Zend Technologies Inc.
</div>
EOQ;
		if (IN_DEV) {
			$footerHtml .= "<h1>Database operations</h1>"
				. implode('<Br />', \zblog\data\Adapter::getAdapter()->getAllOperations());
		}

        return $footerHtml;
        
    }
}