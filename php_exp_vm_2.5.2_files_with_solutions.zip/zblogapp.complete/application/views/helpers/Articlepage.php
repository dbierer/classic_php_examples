<?php

class View_Helper_ArticlePage 
{

	public $view;
		
	public function load() 
	{
		$urlHome = $this->view->getVar('urlHome');
		$pageTitle = $this->view->getVar('pageTitle');
		$applicationName = $this->view->getVar('applicationName');
		$entry = $this->view->getVar('entry');
		$comments = $this->view->getVar('comments');
		
		$entryDisplay = '';
		$commentsDisplay = '';
		
		if ($entry != '') {
			
			$entryDisplay .= '<div class="listings">';
			$entryDisplay .= '<h3>' . htmlentities($entry->title, ENT_NOQUOTES) . '</h3>';
			
			$entryDisplay .= '<p>By author | ' . $entry->comments_count . ' comments | ' . date('D, M j, Y  h:i a T', $entry->modified);
 			$entryDisplay .= ' <a href="' . $urlHome . '/article/view/id/' . $entry->entry_id . '/comment/add">Add Comment</a> - <a href="' . $urlHome . '/article/send/id/'.$entry->entry_id.'">Send to friend</a></p>';
			$entryDisplay .= '<p>' . htmlentities($entry->content, ENT_NOQUOTES) . '</p>';
			$entryDisplay .= '</div>';
		}
		
		if (count($comments) != 0) {
			$commentsDisplay .= '<div class="listings">'; 
			$commentsDisplay .= '<h3>Comments</h3>'; 
			
			foreach ($comments as $comment) {
				
				$commentsDisplay .= '<h4>' . htmlentities($comment->title, ENT_NOQUOTES) . '</h4>';
				$commentsDisplay .= '<p>By ' . $comment->email . ' ' . date('D, M j, Y  h:i a T', $comment->modified);
				$commentsDisplay .= '<p>' . htmlentities($comment->comment, ENT_NOQUOTES) . '</p>';
			}
			
			$commentsDisplay .= '</div>';
			$entryDisplay .= $commentsDisplay;
			
		}
		
		if ($this->view->getVar('displayCommentForm') == true ) {
			
			$entryDisplay .= '<h4>Add Comment</h4>';
			
			$message 	= $this->view->getVar('message');
			$submitCheckInput = '<input type="hidden" name="comment_submit_check" value="1">';
    		$commentSubmit = '<input type="submit" name="submit" value="Add Comment" size="10">';
    		$textAreaLabel = '<label for="comment-content">Your Comments</label>';
    		$textArea = '<textarea id="edit-article" name="comment-content" value=""></textarea>';
    		$titleLabel = '<label for="comment-title">Title for your comment</label>';
    		$titleInput = '<input type="text" id="f_l_title" name="comment-title" size="40" maxlength="120">';
    		$emailLabel = '<label for="comment-email">Your email address</label>';
            $emailInput = '<input type="text" id="f_l_email" name="comment-email" size="40" maxlength="120">';
            $entryIdInput = '<input type="hidden" name="id" value="' . $entry->entry_id . '">';
            $commentInput = '<input type="hidden" name="comment" value="add">';
            
    		$commentsHtml = <<<EOQ
<div id="admin-form">			
	$message			
	<div class="item">
	<form action="$urlHome/article/view/" method="post">
	$entryIdInput
    $commentInput		
		$titleLabel
		<div class="input">
			$titleInput
    	</div>
    	$emailLabel
		<div class="input">
			$emailInput
    	</div>	
    	$textAreaLabel
    	<div class="input">	
			$textArea
    	</div>	
		<div class="input">	
			$commentSubmit
    	</div>		
				
	</form>
</div>				
EOQ;
		$entryDisplay .= $commentsHtml;
			
		}
		
		
		
		return  $entryDisplay;
        
    }
    
}