<?php

class View_Helper_Loginform
{

	public $view;
		
	
	public function load() 
	{
		$errorMessage = $this->view->getVar('errorMessage');
		
		$urlHome = $this->view->getVar('urlHome');
		
        $submitCheckInput = '<input type="hidden" name="login_submit_check" value="1">';
        $userNameInput = '<input type="text" name="user_name" id="f_l_username" size="15" maxlength="15">';
        $userNameLabel = '<label for="user_name">Username</label>';
        $passwordInput = '<input type="password" name="passwd" id="f_l_password" size="15" maxlength="15" class="genText">';
        $passwordLabel = '<label for="passwd">Password</label>';
		$submitform = '<input type="submit" value="Login" class="genText">';
		
        $loginFormHtml = <<<EOQ
<div id="login-form">
	
	<h3>Login to your Account</h3>
	<form action="$urlHome/login" style="margin:1;" method="POST">

    	$submitCheckInput
		<div class="item">

		    $userNameLabel
			<div class="input">
			    $userNameInput
			</div>
		</div>
		<div class="item">
			$passwordLabel
			<div class="input">

				$passwordInput
			</div>
		</div>
		<div class="item">
			<div class="input">
				$submitform
			</div>
		</div>
		<div class="error">$errorMessage</div>
	</form>

</div>
EOQ;

        return $loginFormHtml;
        
    }
}