<?php

namespace models;

use \zblog\data\Adapter as DatabaseAdapter;
use \zblog\log\Logger;
/**
 * models/Articles.php 
 * File contains the ZBlog_Model_Articles class.
 * Class for Database manip operations.
 * 
 * @author Zend Technologies Inc.
 */


/**
 * ZBlog_Model_Articles
 * Class contains methods for manipulating the WIKI data stored
 * in SQLite database.
 *
 */
class Blogs
{

    /**
     * function gets all Blog entries in the db
     *
     * @return mixed - result set containing all records in the listings table
     * 
     * fetchall: returns an array of rows, each of which is an associative array. 
     * The keys of the associative array are the columns or column aliases named in the select query.
     */
    public static function getEntries() 
    {
    	
    	$sql = <<<EOQ
SELECT a.entry_id AS entry_id, a.title AS title, a.content AS content, a.modified AS modified, count(b.comments_id) as comments_count 
FROM blogentries as a
LEFT JOIN blogcomments as b
ON a.entry_id = b.entry_id
AND b.approval_status = 1
GROUP BY a.entry_id
ORDER BY a.modified DESC
EOQ;
        //$sql = 'select entry_id, title, content, modified from blogentries';
    	try {
    		$stmt = DatabaseAdapter::getAdapter()->query( $sql );
    		return $stmt->fetchAll(\PDO::FETCH_OBJ);
    		
    	} catch (PDOException $e) {
			Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );

    	}
    	return null;
    }
    
    /**
     * function gets a list of Article title in the BLog database
     *
     * @return mixed - array of rows containing title, listing_id and modified date
     */
    public static function getEntryTitles() 
    {
    	
    	$sql = <<<EOQ
SELECT a.entry_id AS entry_id, a.title AS title, a.modified AS modifieD, count(b.comments_id) as comments_count 
FROM blogentries as a
LEFT JOIN blogcomments as b
ON a.entry_id = b.entry_id
AND b.approval_status = 1
GROUP BY a.entry_id
ORDER BY a.modified DESC
EOQ;

    	try {
    		$stmt = DatabaseAdapter::getAdapter()->query( $sql );
    		return $stmt->fetchAll(\PDO::FETCH_OBJ);
    		
    	} catch (PDOException $e) {

    		Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );

    	}
    }

    public static function getEntry( $entryId ) 
    {
                // read from the Zend Data Cache (shared memory)
                $result = zend_shm_cache_fetch("post_$entryId");
                if (empty($result)) {
                $sql = <<<EOQ
SELECT a.entry_id AS entry_id, a.title AS title, a.content AS content, a.modified AS modified, count(b.comments_id) as comments_count
FROM blogentries as a
LEFT JOIN blogcomments as b
ON a.entry_id = b.entry_id
AND b.approval_status = 1
WHERE a.entry_id = ?
GROUP BY a.entry_id
EOQ;
				/**
				 * L8: Switch to procedure call
				 */
                //$sql= "call getEntry($entryId)";
                try {
                        $stmt = DatabaseAdapter::getAdapter()->prepare( $sql );
                        if ($stmt->execute(array($entryId))) {
                                $result= $stmt->fetch(\PDO::FETCH_OBJ);
                        }
                } catch (PDOException $e) {
                        Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );
                }
                // cache the result for 1 hour
                zend_shm_cache_store("post_$entryId", $result,3600);
        }
        return $result;    	
    }      
    
    
    public static function createEntry($entry) 
    {
        $modified = time();
    	
    	$sql = <<<EOQ
INSERT INTO blogentries
(title, content, modified)
VALUES
(?, ?, ?)
EOQ;
   	
		try {
			
    		$stmt = DatabaseAdapter::getAdapter()->prepare( $sql );
    		if ($stmt->execute(array($entry['title'], $entry['content'], $modified))) {
    			$lastEntryId = DatabaseAdapter::getAdapter()->lastInsertId();
    			return $lastEntryId;
    		}
		} catch (PDOException  $e) {
			
			Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );
			
		}
		return null;
    }    
    
    public static function getRecentEntries() 
    {
    	
    	$sql = <<<EOQ
SELECT entry_id, title, modified 
FROM blogentries 
ORDER BY modified DESC
LIMIT 0,5
EOQ;
  
    	try {
    		$stmt = DatabaseAdapter::getAdapter()->query( $sql );
    		return $stmt->fetchAll(\PDO::FETCH_OBJ);
    		
    	} catch (PDOException $e) {

    		Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );

    	}
    	return null;
    	
    } 
    
    public static function searchEntries($query) 
    {
    	$query = '%'.$query.'%';
    	$sql = <<<EOQ
SELECT a.entry_id AS entry_id, a.title AS title, a.content AS content, a.modified AS modified, count(b.comments_id) as comments_count 
FROM blogentries as a
LEFT JOIN blogcomments as b
ON a.entry_id = b.entry_id
AND b.approval_status = 1
WHERE a.title LIKE ?
OR a.content LIKE ?
GROUP BY a.entry_id
ORDER BY a.modified DESC
EOQ;

    	try {
    		$stmt = DatabaseAdapter::getAdapter()->prepare( $sql );
    		if ($stmt->execute(array($query, $query))) {
    			return $stmt->fetchAll(\PDO::FETCH_OBJ);
    		}
    	} catch (PDOException $e) {
			Logger::getInstance()->writeLog( $e->getMessage(), 'ERR' );

    	}
    	
    	return null;
    	
    }     

}
