<?php

namespace models;

/**
 * models/Soap.php 
 * File contains the \models\Soap class.
 * Class providing data for Soap related operations.
 * 
 * @author Zend Technologies Inc.
 */


class Soap
{

    /**
     * function gets all Blog entries in the db
     *
     * @return mixed - result set containing all records in the listings table
     * 
     * getArticles: returns an array of rows, each of which is an associative array. 
     * The keys of the associative array are the columns or column aliases named in the select query.
     */
    public function getArticles() 
    {
    	$return = array();
    	foreach (Blogs::getEntries() AS $entry) {
    		$ent = array();
    		foreach ($entry AS $key => $val) {
    			$ent[$key] = utf8_encode($val);
    		}
    		$return[] = $ent;
    	}
    	return $return;
    }

}
