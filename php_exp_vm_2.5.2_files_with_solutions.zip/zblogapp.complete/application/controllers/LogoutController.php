<?php

namespace controllers;

class LogoutController extends \zblog\controller\ControllerAbstract
{

	public function indexAction()
	{
		
		session_destroy();
		
		header('Location:' . URL_HOME);
		exit;
	}
}