<?php

namespace controllers;

use \zblog\util\Validators as Validators;
use \zblog\log\Logger;

class ArticleController extends \zblog\controller\ControllerAbstract 
{
	public $view;

	public function indexAction()
	{
		
	}
	
	public function viewAction() 
	{
		$request = $this->view->getRequestParams();
		
		$this->view->setVar('urlHome', URL_HOME);
		$this->view->setVar('applicationName', APP_NAME);
		$this->view->setVar('pageTitle', "Articles");

		$requestEntryId = (isset($request['id'])) ? (int)$request['id'] : 0;
		
		$entryId = empty($requestEntryId) ? 0 : $requestEntryId;

		if (array_key_exists('comment', $request)) {
			if ($request['comment'] == 'add') {

				$this->view->setVar('displayCommentForm', true);


				if (array_key_exists('submit', $request)) {

					if ($request['submit'] == 'Add Comment') {

						$commentTitle 	= $request['comment-title'];
						$commentEmail 	= $request['comment-email'];
						$commentContent = $request['comment-content'];

						$errMsg = '';

						if (!Validators::validTitleLength($commentTitle)) {

							$errMsg .= '<p>Title should be 1 - 120 chars</p>';
						}

						if (!Validators::validCommentLength($commentContent)) {

							$errMsg .= '<p>Comment should be 1 - 255 chars</p>';
						}

						if (!Validators::validEmail($commentEmail)) {

							$errMsg .= '<p>Please enter a valid email</p>';
						}

						if ($errMsg == '') {
							$comment = array(
								'title'      	=> $commentTitle,
								'comment'      	=> $commentContent,
								'email'			=> $commentEmail,
								'approvalStatus' => 0,  //Default for all new entries
								'entryId'		=> $entryId,
							);

							//Submit to database

							if (\models\Comments::AddComment($comment)) {
								$this->view->message = 'Your Comment has been submitted.';
								
								/*
								 * M6Ex7: Sending new email when a comment is added
								 */
								if (defined('ADMIN_EMAIL')) {
									mail(ADMIN_EMAIL, 'New posting', 'A new comment has been posted');
								}
								
							} else {
								$this->view->message = 'There was a problem adding your comment. Please try again!';
							}
						} else {
							$this->view->message = $errMsg;
						}

					}
				}
			}
		}


		$entry = '';
		
		if ($entryId != 0) {
			$entry = \models\Blogs::getEntry($entryId);
			
			/**
			 * M6Ex3(1): Adding browser caching using the Last-Modified header
			 */
			$eTag = "$entryId-$entry->modified";
			header('Expires: '.gmdate("D, d M Y H:i:s", $entry->modified+31536000) . " GMT");
			header('Last-Modified: '.gmdate("D, d M Y H:i:s", $entry->modified) . " GMT");
			header("ETag: $eTag");
			header("Pragma: cache");
			header("Cache-Control: public, must-revalidate, max-age=0");
			if (isset($_SERVER['HTTP_IF_NONE_MATCH']) && $_SERVER['HTTP_IF_NONE_MATCH'] = $eTag ) {
			   header('Not Modified', true, 304);
			   return;
			}
			
 			/**
 			 * L2Ex1: Writing to files
 			 * 
 			 * @var $logger Logger
 			 */
 			$logger = \zblog\log\Logger::getInstance();
 			$logger->logEntry($entry->entry_id, $entry->title);
 			
 			/** 
 			 * M6Ex6: Part1: Storing the information about the last article 
 			 * 				 that was read.
 			 */
 			$data = new \stdClass();
 			$data->entry_id = $entry->entry_id;
 			$data->title    = $entry->title;
 			$_SESSION['lastread'] = $data;
		}
		
		
		$this->view->setVar('entry', $entry);
		$recentEntries = \models\Blogs::getRecentEntries();
		$this->view->setVar('recententries', $recentEntries);
		
		$blogComments = \models\Comments::getComments($entryId);
		$this->view->setVar('comments', $blogComments);
				
    }
    
    public function sendAction() 
 	{
 		$request = $this->view->getRequestParams();
 		
 		$this->view->setVar('urlHome', URL_HOME);
 		$this->view->setVar('applicationName', APP_NAME);
 		$this->view->setVar('pageTitle', "Send a Friend");
 
 		$requestEntryId = (isset($request['id'])) ? (int)$request['id'] : 0;
 		$entryId = empty($requestEntryId) ? 0 : $requestEntryId;
 		
 		$entry = '';
 		if ($entryId != 0) {
 			$entry = \models\Blogs::getEntry($entryId);
 		}
 		$this->view->setVar('entry', $entry);
 		
 		if (array_key_exists('email', $request)) {
 			$sender_name= trim($request['name']);
 			$sender_email= $request['email'];
 			$friend_email= $request['friend'];
 			$comment= $request['comment'];
 			
 			$errMsg='';
 			if (empty($sender_name)) {
 				$errMsg .= '<p>Please enter your name</p>';
 			} else {
 				$this->view->setVar('name', $sender_name);
 			}
 			if (!Validators::validEmail($sender_email)) {
 				$errMsg .= '<p>Please enter a valid email</p>';
 			} else {
 				$this->view->setVar('email', $sender_email);
 			}
 			if (!Validators::validEmail($friend_email)) {
 				$errMsg .= '<p>Please enter a valid email for your friend</p>';
 			} else {
 				$this->view->setVar('friend', $friend_email);
 			}
 			
 			$this->view->setVar('comment', $comment);
 			
 			if (empty($errMsg)) {
 				$headers= "From: $sender_email";
 				$message= "$sender_name is sending you this article:\n";
 				$message.= URL_HOME.'/article/view/id/'.$entryId;
 				
 				if (!empty($comment)) {
 					$message.= "\nWith the following comment:\n".$comment;
 				}
 				print_r($message);
 				
 				if (!mail($friend_email,$entry->title,$message,$headers)) {
 					Logger::getInstance()->writeLog('Error sending email to $friend_email','ERR');
 					$this->view->setVar('delivery', 'I failed to send the email to your friend, sorry.');
 				} else {
 					$this->view->setVar('delivery', 'The email has been sent successfully.');
 				}
 			} else {
 				$this->view->setVar('error', $errMsg);
 			}
 		}
 
 		$recentEntries = \models\Blogs::getRecentEntries();
 		$this->view->setVar('recententries', $recentEntries);
 		
 	}	
}